@echo off
setlocal DisableDelayedExpansion
E:\Node\node.exe "E:\Skill ＆ Harness\tmp\closeout-openclaw-20260919\node_modules\openclaw\openclaw.mjs" %*
