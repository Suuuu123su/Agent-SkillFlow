"""Harness Adapter 的最小公开合同。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from skillflow.adapters.checkpoint import HarnessCheckpoint
    from skillflow.instrumentation.tool_receipt import ToolReceipt
    from skillflow.models.provenance import Artifact
    from skillflow.models.references import FixtureImplementationRef
    from skillflow.models.tool_calls import ToolActionAttempt


@dataclass(frozen=True, slots=True)
class HarnessSession:
    """一次 Harness Session 的稳定标识。"""

    session_id: str


@dataclass(frozen=True, slots=True)
class SkillBinding:
    """Skill 主体与白名单 fixture 实现的绑定。"""

    skill_id: str
    implementation: FixtureImplementationRef


@dataclass(frozen=True, slots=True)
class SkillInvocation:
    """一次显式 Skill 调用。"""

    skill_id: str
    input_artifact_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SkillInvocationResult:
    """Skill 返回 Artifact 及本次调用产生的 Receipt。"""

    output: Artifact
    receipts: tuple[ToolReceipt, ...]
    attempts: tuple[ToolActionAttempt, ...]
    skipped_action_ids: tuple[str, ...]
    call_id: str
    input_artifact_ids: tuple[str, ...]


class HarnessAdapter(Protocol):
    """T05 最小 Harness 合同，不包含 checkpoint/restore。"""

    def start_session(self, session: HarnessSession) -> None:
        """开始一个隔离 Session。"""
        ...

    def load_skill(self, binding: SkillBinding) -> None:
        """从固定 fixture registry 加载 Skill。"""
        ...

    def invoke_skill(self, invocation: SkillInvocation) -> SkillInvocationResult:
        """执行一次确定性 Skill 调用。"""
        ...

    def end_session(self) -> None:
        """结束当前 Session。"""
        ...


class CheckpointableHarnessAdapter(HarnessAdapter, Protocol):
    """T10 在最小 Harness 之上的 checkpoint/restore 扩展。"""

    def checkpoint(self) -> HarnessCheckpoint:
        """在静止 step 边界冻结完整运行态。"""
        ...

    def restore(self, checkpoint: HarnessCheckpoint) -> None:
        """把 checkpoint 恢复到一个全新分支 Harness。"""
        ...
